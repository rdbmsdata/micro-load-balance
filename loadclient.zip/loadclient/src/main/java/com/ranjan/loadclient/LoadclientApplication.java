package com.ranjan.loadclient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@SpringBootApplication
@RibbonClient(name = "loadbalancer", configuration = LoadBalanceConfiguration.class)
public class LoadclientApplication {
	
	@Bean
	RestTemplate getTemplate() {
		return new RestTemplate();
	}
	
	@Autowired
	RestTemplate restTemplage;

	@GetMapping(path="/empcall")
	public String callEmployeeService() {
		
		String empDetails = this.restTemplage.getForObject("http://loadbalancer/emps", String.class);
		System.out.println("Employee details is "+empDetails);
		return empDetails;
	}
	
	public static void main(String[] args) {
		SpringApplication.run(LoadclientApplication.class, args);
	}
}
