/**
 * 
 */
package com.ranjan.loadbalancer.service;

import java.util.ArrayList;
import java.util.List;

import com.ranjan.loadbalancer.model.Employee;

/**
 * @author rdutta
 *
 */
public class EmployeeService {

	public EmployeeService() {

	}

	public List<Employee> getEmployees() {
		List<Employee> empList = new ArrayList<Employee>();
		Employee empOne = new Employee();
		empOne.setEmpAddress("Town Center");
		empOne.setEmpId(001);
		empOne.setEmpName("Ranjan");

		Employee empTwo = new Employee();
		empTwo.setEmpAddress("Town Center");
		empTwo.setEmpId(002);
		empTwo.setEmpName("Amit");

		Employee empThree = new Employee();
		empThree.setEmpAddress("Town Center");
		empThree.setEmpId(003);
		empThree.setEmpName("Abhay");

		empList.add(empOne);
		empList.add(empTwo);
		empList.add(empThree);

		return empList;

	}
}
