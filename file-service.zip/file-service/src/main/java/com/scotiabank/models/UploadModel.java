/**
 * 
 */
package com.scotiabank.models;

import java.io.Serializable;

import org.springframework.web.multipart.MultipartFile;

/**
 * @author rdutta
 *
 */
public class UploadModel implements Serializable {

	private String fileId;
	private String description;
	private MultipartFile file;

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	@Override
	public String toString() {
		return "UploadModel [fileId=" + fileId + ", description=" + description + "]";
	}
	
	

}
