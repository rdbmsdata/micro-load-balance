package com.scotiabank.controller;



/**
 * @author rdutta
 *
 */
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;


import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class RestUploadController {

	private final Logger logger = LoggerFactory.getLogger(RestUploadController.class);

	/**
	 * @Path will be host:8080/{PostMapping} 
	 * @param fieldId
	 * @param description
	 * @param uploadfile
	 * @return 
	 */
	@PostMapping("/api/upload")
	public ResponseEntity<?> uploadFile(@RequestParam("fieldId") String fieldId,
			@RequestParam("description") String description, @RequestParam("files") MultipartFile uploadfile) {

		String content = "";
		logger.debug("File upload request!");
		logger.debug("Field Id : " + fieldId);
		logger.debug("Description : " + description);

		if (uploadfile.isEmpty()) {
			return new ResponseEntity("please select a file!", HttpStatus.OK);
		}

		try {

			content = readFiles(uploadfile);

		} catch (IOException e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity("Successfully read - File Content : " + content, new HttpHeaders(), HttpStatus.OK);

	}

	
	/**
	 * Read the content of the file
	 * @param file
	 * @return
	 * @throws IOException
	 */
	private String readFiles(MultipartFile file) throws IOException {

		String fileContent = "";

		if (!file.isEmpty()) {
			byte[] bytes = file.getBytes();
			fileContent = new String(bytes);
		}
		logger.debug("File content is : ");
		logger.debug(fileContent);
		return fileContent;

	}

}
