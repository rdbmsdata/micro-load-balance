package com.scotiabank;

/**
 * @author rdutta
 *
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileServiceApplication {
	 private int maxUploadSizeInMb = 10 * 1024 * 1024;
	public static void main(String[] args) {
		SpringApplication.run(FileServiceApplication.class, args);
	}
}
